package pepse.util;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.TextRenderable;
import danogl.util.Vector2;
import pepse.world.Avatar;

import java.util.function.Consumer;

/**
 * Object to Counter Energy of avatar in the game.
 */
public class EnergyCounter {
    private static final float ENERGY_BAR_LOCATION_FROM_AVATAR = 300;
    private static final String START_TITLE = "start";

    /** EnergyCounter's constructor.
     * @param avatar avatar of the game.
     * @param gameObjects objects og the game.
     * @param topLeftCorner location.
     * @param dimensions dimensions of object.
     * @return GameObject of EnergyCounter.
     */
    public static GameObject createEnergyCounter(Avatar avatar, GameObjectCollection gameObjects,
                                                 Vector2 topLeftCorner, Vector2 dimensions) {
        TextRenderable textRenderable = new TextRenderable(START_TITLE);
        GameObject energyCounter = new GameObject(topLeftCorner, dimensions, textRenderable);
        gameObjects.addGameObject(energyCounter, Layer.UI);
        energyCounter.addComponent(deltaTime -> {
            textRenderable.setString(Integer.toString((int) avatar.getEnergy()));
            energyCounter.setCenter(avatar.getCenter().subtract(new
                    Vector2(ENERGY_BAR_LOCATION_FROM_AVATAR
                    , ENERGY_BAR_LOCATION_FROM_AVATAR)));
        });
        return energyCounter;

    }
}