package pepse.world;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.ImageReader;
import danogl.gui.UserInputListener;
import danogl.gui.rendering.AnimationRenderable;
import danogl.gui.rendering.Renderable;
import danogl.gui.rendering.TextRenderable;
import danogl.util.Vector2;

import java.awt.event.KeyEvent;

/**
 * Avatar's class is responsible for the player's image.
 */
public class Avatar extends GameObject {
    private static final float VELOCITY_X = 300;
    private static final String STATIC_PATH = "assets/HAT_MAN1.png";
    private static final String[] DYNAMIC_PATHS = new String[]{"assets/HAT_MAN1.png",
    "assets/HAT_MAN2.png", "assets/HAT_MAN3.png", "assets/HAT_MAN4.png"};
    private static final float JUMP_SPEED = -200;
    private static final int INITIAL_ENERGY = 100;
    private static final float ENERGY_CHANGE = 0.5f;
    private static final int MAX_ENERGY = 100;
    private static final float GRAVITY = 120;
    private static final float DEFAULT_AVATAR_SIZE = 50;
    private static final double TIME_BETWEEN_CLIPS = 0.5f;
    private static final float MAX_Y_VELOCITY_DOWN = 250;
    private static final float MAX_VELOCITY_X_RIGHT = 300;
    private float energy;
    private final AnimationRenderable dynamicRenderable;
    private final UserInputListener inputListener;

    /**
     * Constructor for Avatar object.
     *
     * @param topLeftCorner      - Vector2
     * @param inputListener      - UserInputListener
     * @param staticRenderable   - Renderable
     * @param dynamicRenderable- AnimationRenderable
     */
    public Avatar(Vector2 topLeftCorner, UserInputListener inputListener,
                  Renderable staticRenderable, AnimationRenderable dynamicRenderable) {
        super(topLeftCorner, Vector2.ONES.mult(DEFAULT_AVATAR_SIZE), staticRenderable);
        physics().preventIntersectionsFromDirection(Vector2.ZERO);
        this.dynamicRenderable = dynamicRenderable;
        transform().setAccelerationY(GRAVITY);
        this.inputListener = inputListener;
        this.energy = INITIAL_ENERGY;
    }

    /**
     * creates avatar with
     * @param gameObjects   -GameObjectCollection
     * @param layer         - int
     * @param topLeftCorner - Vector2
     * @param inputListener - inputListener
     * @param imageReader   - ImageReader
     * @return Avatar to be used.
     */
    public static Avatar create(GameObjectCollection gameObjects, int layer, Vector2 topLeftCorner,
                                UserInputListener inputListener, ImageReader imageReader) {
        AnimationRenderable dynamicRenderable = new AnimationRenderable(DYNAMIC_PATHS,
                imageReader, true, TIME_BETWEEN_CLIPS);
        Avatar avatar = new Avatar(topLeftCorner, inputListener,
                imageReader.readImage(STATIC_PATH, true), dynamicRenderable);
        gameObjects.addGameObject(avatar, layer);
        return avatar;
    }

    /**
     * returns Energy.
     * @return energy.
     */
    public float getEnergy() {
        return energy;
    }

    /**
     * check if player wants to move right or left and performs if so.
     */
    private float checkRightOrLeftMove(float xVel) {
        if (inputListener.isKeyPressed(KeyEvent.VK_LEFT)) {
            renderer().setIsFlippedHorizontally(true);
            xVel -= VELOCITY_X;
        } else if (inputListener.isKeyPressed(KeyEvent.VK_RIGHT)) {
            renderer().setIsFlippedHorizontally(false);
            xVel += VELOCITY_X;
        }
        return xVel;
    }

    /**
     * check if player wants to fly and performs if so.
     */
    private void checkFlyMove(){
        if (inputListener.isKeyPressed(KeyEvent.VK_SPACE) &&
                inputListener.isKeyPressed(KeyEvent.VK_SHIFT) && energy > 0) {
            energy -= ENERGY_CHANGE;
            transform().setVelocityY(JUMP_SPEED);
        }
    }

    /**
     * check if player wants to jump and performs if so.
     */
    private void checkJumpMove(){
        if (inputListener.isKeyPressed(KeyEvent.VK_SPACE) && getVelocity().y() == 0) {
            transform().setVelocityY(JUMP_SPEED);
        } else if (getVelocity().y() == 0.0) {
            if (energy < MAX_ENERGY) {
                energy += ENERGY_CHANGE;
            }
        }
    }

    /**
     * updates for avatar's instance.
     * @param deltaTime The time elapsed, in seconds, since the last frame. Can
     *                  be used to determine a new position/velocity by multiplying
     *                  this delta with the velocity/acceleration respectively
     *                  and adding to the position/velocity:
     *                  velocity += deltaTime*acceleration
     *                  pos += deltaTime*velocity
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        float xVel = 0;
        xVel = checkRightOrLeftMove(xVel);
        renderer().setRenderable(dynamicRenderable);
        transform().setVelocityX(xVel);
        checkFlyMove();
        checkJumpMove();
        if (getVelocity().y() > MAX_Y_VELOCITY_DOWN) {
                transform().setVelocityY(MAX_Y_VELOCITY_DOWN);
        }
        if (getVelocity().x() > MAX_VELOCITY_X_RIGHT) {
            transform().setVelocityX(MAX_VELOCITY_X_RIGHT);
        }
    }
}
