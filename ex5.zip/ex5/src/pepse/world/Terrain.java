package pepse.world;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.rendering.RectangleRenderable;
import danogl.util.Vector2;
import pepse.util.PerlinNoise;

import java.awt.*;
import java.util.HashMap;

/**
 * Terrain's class creates ground in the game.
 */
public class Terrain {
    public static final int BLOCK_SIZE = 30;
    public static final float START_LOCATION = (float) 2/ (float)3;
    private static final String BLOCK_TAG_FORMAT = "block %d %d";
    private static final Color BASE_GROUND_COLOR = new Color(212, 123, 74);
    private static final int TERRAIN_DEPTH = 10;
    private static final float WINDOW_PREFACTOR = 330;
    private static final int BLOCK_LAYER = -100;
    private final int groundLayer;
    private final float groundHeightAtX0;
    private final HashMap<Float, Float> xToNoiseMap;
    private final GameObjectCollection gameObjects;
    private final PerlinNoise perlin;
    private final int blockSize;
    private final int upperTerrainLayer;

    /**
     * Terrain's constructor.
     * @param gameObjects objects of the game.
     * @param groundLayer layer of the ground.
     * @param windowDimensions dimensions of the window.
     * @param seed seed of the game.
     */
    public Terrain(GameObjectCollection gameObjects, int groundLayer,
                   Vector2 windowDimensions, int seed) {
        this.groundLayer = groundLayer;
        this.gameObjects = gameObjects;
        groundHeightAtX0 = windowDimensions.y() * START_LOCATION;
        perlin = new PerlinNoise(seed);
        xToNoiseMap = new HashMap<>();
        upperTerrainLayer = 0;
        blockSize = 30;
    }

    /**
     * Terrain's constructor.
     * @param gameObjects objects of the game.
     * @param groundLayer layer of the ground.
     * @param windowDimensions dimensions of the window.
     * @param seed seed of the game.
     */
    public Terrain(GameObjectCollection gameObjects, int groundLayer, int upperTerrainLayer,
                   Vector2 windowDimensions, int seed, int blockSize) {
        this.upperTerrainLayer = upperTerrainLayer;
        this.groundLayer = groundLayer;
        this.gameObjects = gameObjects;
        groundHeightAtX0 = windowDimensions.y() * START_LOCATION;
        perlin = new PerlinNoise(seed);
        xToNoiseMap = new HashMap<>();
        this.blockSize = blockSize;
    }

    /**
     * gets ground height at given x coordinate.
     * @param x coordinate.
     * @return ground height.
     */
    public float groundHeightAt(float x) {
        if (xToNoiseMap.containsKey(x)) {
            return xToNoiseMap.get(x);
        }
        float noise = groundHeightAtX0 + ((float) blockSize * (float) (Math.floor((perlin.noise(x) *
                        WINDOW_PREFACTOR) / blockSize)));
        xToNoiseMap.put(x, noise);
        return noise;
    }

    /**
     * calculates x according to blockSize/
     * @param x x coordinate.
     * @return calculated x.
     */
    private int calculateX(int x){
        return (int) (blockSize * Math.floor((float) x / blockSize));
    }

    /**
     * creates ground in given range.
     * @param minX left coordinate to create ground from.
     * @param maxX right coordinate to create ground to.
     */
    public void createInRange(int minX, int maxX) {
        int startX = calculateX(minX);
        int endX = calculateX(maxX);
        for (; startX < endX; startX += blockSize) {
            float yPosition = groundHeightAt(startX);
            addBlocksInCol(startX, yPosition, blockSize);
        }
    }

    /**
     * removes blocks in given range.
     * @param minX left coordinate to create ground from.
     * @param maxX right coordinate to create ground to.
     */
    public void removeInRange(int minX, int maxX) {
        int startX = calculateX(minX);
        int endX = calculateX(maxX);
        for (GameObject block : gameObjects.objectsInLayer(upperTerrainLayer)) {
            if (block.getCenter().x() >= startX && block.getCenter().x() <= endX) {
                gameObjects.removeGameObject(block, upperTerrainLayer);
            }
        }
        for (GameObject block : gameObjects.objectsInLayer(groundLayer)) {
            if (block.getCenter().x() >= startX && block.getCenter().x() <= endX) {
                gameObjects.removeGameObject(block, groundLayer);
            }
        }
    }

    /**
     * adds blocks in each col up to given height.
     * @param startX x coordinate.
     * @param yPosition height.
     * @param size size of blocks.
     */
    private void addBlocksInCol(int startX, float yPosition, int size) {
        for (int i = 0; i < TERRAIN_DEPTH; i++) {
            Block block = new Block(Vector2.ZERO, new
                    RectangleRenderable(BASE_GROUND_COLOR), BLOCK_SIZE);
            block.setCenter(new Vector2((float) startX, i * size + yPosition));
            if (i <= 1) {
                gameObjects.addGameObject(block, upperTerrainLayer);
            } else {
                gameObjects.addGameObject(block, groundLayer);
            }
            block.setTag(String.format(BLOCK_TAG_FORMAT, startX, i));
        }
    }
}
