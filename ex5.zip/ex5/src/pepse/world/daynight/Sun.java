package pepse.world.daynight;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.components.CoordinateSpace;
import danogl.components.Transition;
import danogl.gui.rendering.OvalRenderable;
import danogl.util.Vector2;

import java.awt.*;
import java.util.function.Consumer;

/**
 * Sun's class is in charge of the sun of the game.
 */
public class Sun {
    private static final String SUN_TAG = "sun";
    private static final float ELIPSE_RADIUS_FACTOR = 4;
    private static final float SUN_INITIAL_POSITION = 20;
    private static final float SUN_SIZE_FACTOR = 0.25f;
    private static final float UP_VECTOR_PREFACTOR = 3;
    private static final float ANGLE_DIFF = 1;
    private static final float Y_MOVEMENT_PREFACTOR = 1.2f;
    private static final float SUN_MOVEMENT_X_PREFACTOR = 0.5f;
    private static final float SUN_MOVEMENT_Y_PREFACTOR = 0.7f;
    private static final float STARTING_SUN_ANGLE = 0f;
    private static final float FINAL_SUN_ANGLE = 360f;

    /**
     * creates GameObject that represents Sun.
     * @param gameObjects gameObjects of the game.
     * @param layer layer of the sun.
     * @param windowDimensions dimensions of thw window.
     * @param cycleLength length of cycle of one day.
     * @return GameObject.
     */
    public static GameObject create(GameObjectCollection gameObjects, int layer,
                                    Vector2 windowDimensions, float cycleLength) {
        GameObject sun = new GameObject(new Vector2(windowDimensions.x(), SUN_INITIAL_POSITION),
                windowDimensions.mult(SUN_SIZE_FACTOR), new OvalRenderable(Color.YELLOW));
        Vector2 initialVector = Vector2.UP.mult(windowDimensions.x() / UP_VECTOR_PREFACTOR);
        sun.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
        gameObjects.addGameObject(sun, layer);
        Consumer<Float> sunLambda = angle -> {
            angle += ANGLE_DIFF;
            float sin = (float) Math.sin(Math.toRadians(angle));
            float cos = (float) Math.cos(Math.toRadians(angle));
            float x = initialVector.x() * sin - initialVector.y() * Y_MOVEMENT_PREFACTOR * cos;
            float y = initialVector.x() * cos + initialVector.y() * sin;
            sun.setCenter(new Vector2(SUN_MOVEMENT_X_PREFACTOR * windowDimensions.x() - x,
                    SUN_MOVEMENT_Y_PREFACTOR * windowDimensions.y() + y));
        };
        new Transition<>(sun, sunLambda, STARTING_SUN_ANGLE, FINAL_SUN_ANGLE,
                Transition.LINEAR_INTERPOLATOR_FLOAT,
                cycleLength, Transition.TransitionType.TRANSITION_LOOP, null);
        return sun;
    }
}
