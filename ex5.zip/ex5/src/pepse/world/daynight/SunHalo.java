package pepse.world.daynight;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.components.CoordinateSpace;
import danogl.gui.rendering.OvalRenderable;
import danogl.util.Vector2;

import java.awt.*;

 /**
 *  * SunHalo's class is in charge of the sunHalo of the game.
 *  */
public class SunHalo {
    private static final String SUN_HALO_TAG = "sun_halo";
    private static final float HALO_DIMENSIONS_PREFACTOR = 1.5f;

    /**
     * creates the Halo and adds to gameObjects.
     * @param gameObjects - GameObjectCollection
     * @param layer- int
     * @param sun - GameObject
     * @param color - color of SunHalo
     * @return GameObject.
     */
    public static GameObject create(GameObjectCollection gameObjects, int layer, GameObject sun, Color color){
        GameObject sunHalo = new GameObject(new Vector2(sun.getTopLeftCorner().x(),
                sun.getTopLeftCorner().y()), sun.getDimensions().mult(HALO_DIMENSIONS_PREFACTOR),
                new OvalRenderable(color));
        sunHalo.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
        gameObjects.addGameObject(sunHalo, layer);
        sunHalo.addComponent(deltaTime -> sunHalo.setCenter(sun.getCenter()));
        sunHalo.setTag(SUN_HALO_TAG);
        return sunHalo;
    }
}
