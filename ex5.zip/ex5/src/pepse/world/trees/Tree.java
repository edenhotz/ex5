package pepse.world.trees;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.components.ScheduledTask;
import danogl.components.Transition;
import danogl.gui.rendering.RectangleRenderable;
import danogl.util.Vector2;
import pepse.world.Block;

import java.awt.*;
import java.util.HashMap;
import java.util.Objects;
import java.util.Random;
import java.util.function.Function;

/**
 * Tree class is responsible for creating trees.
 */
public class Tree {
    public static final int STUMP_SIZE = 20;
    private static final int STUMP_BLOCK_GAP = 5;
    private static final int LEAF_SIZE_PLUS_GAP = 16;
    public static final int NUMBER_OF_LEAFS = 3;
    private static final float THRESHOLD_TREES = 0.93f;
    private static final float THRESHOLD_LEAFS = 0.2f;
    private static final Color TREE_STUMP_COLOR = new Color(100, 50, 20);
    private static final Color TREE_LEAF_COLOR = new Color(50, 200, 30);
    private static final float FADEOUT_TIME = 10f;
    private static final String LEAF_TAG = "leaf";
    private static final int N_POTENTIAL_COLORS = 10;
    private static final int GREEN_THRESHOLD = 4;
    private static final int LIGHT_GREEN_THRESHOLD = 6;
    private static final int DARK_GREEN_THRESHOLD = 8;
    private static final int TREE_HEIGHT_MIN = 7;
    private static final int TREE_HEIGHT_MAX = 12;
    private static final int LEAF_LIFETIME_MINIMUM = 5;
    private static final int LEAF_LIFTETIME_MAXIMUM = 60;
    private static final int LEAF_DIETIME_MINIMUM = 5;
    private static final int LEAF_DIETIME_MAXIMUM = 50;
    private static final float LEAF_INITIAL_ANGLE = -1 * (5f);
    private static final float LEAF_FINAL_ANGLE = 10f;
    private static final float LEAF_INITIAL_DIMENSIONS = -1 * (5f);
    private static final float LEAF_FINAL_DIMENSIONS = 8f;
    private static final float LEAF_TRANSITION_ANGLE = 5;
    private static final float LEAF_DIMENSION_TRANSITION_TIME = 7;
    private static final float LEAF_WAIT_TIME = 1f;
    private static final float FULL_OPAQUNESS = 1;
    private static final float LEAF_FALLING_SPEED = 20;
    private static final float MAX_LEAF_RAND = 1;
    private static final float MIN_LEAF_RAND = 0;

    private final Function<Float, Float> groundHeightAt;
    private final int seed;
    private final int blockSize;
    private final int treeLayer;
    private final int leafLayer;
    private final GameObjectCollection gameObjects;
    private Random rand;
    private final int fallingLeafLayer;
    private final int topTreeLayer;
    private final HashMap<Integer, Float> treeXLocationtoHeightMap;

    /**
     * Tree's constructor.
     *
     * @param groundHeightAt   function that calculates ground height at given X.
     * @param seed             of the game.
     * @param blockSize        size of the block.
     * @param treeLayer        layer of trees in the game.
     * @param leafLayer        layer of leafs in the game.
     * @param fallingLeafLayer layer of falling leafs in the game.
     * @param topTreeLayer     layer of top trees in the game.
     * @param gameObjects      objects of the game.
     */
    public Tree(Function<Float, Float> groundHeightAt, int seed, int blockSize, int treeLayer,
                int leafLayer, int fallingLeafLayer, int topTreeLayer, GameObjectCollection gameObjects) {
        this.groundHeightAt = groundHeightAt;
        this.seed = seed;
        this.blockSize = blockSize;
        this.treeLayer = treeLayer;
        this.leafLayer = leafLayer;
        this.fallingLeafLayer = fallingLeafLayer;
        this.topTreeLayer = topTreeLayer;
        this.gameObjects = gameObjects;
        treeXLocationtoHeightMap = new HashMap<>();
    }

    /**
     * create trees in given range.
     *
     * @param minX X coordinate to create tree from.
     * @param maxX X coordinate to create tree to.
     */
    public void createInRange(int minX, int maxX) {
        int startX = (int) (blockSize *
                Math.floor((float) minX / blockSize));
        int endX = (int) (blockSize *
                Math.floor((float) maxX / blockSize));
        for (; startX < endX; startX += blockSize) {
            rand = new Random(Objects.hash(startX, seed));
            float draw = rand.nextFloat();
            if (draw > THRESHOLD_TREES) {
                float perlinReturn = groundHeightAt.apply((float) startX);
                createTree(startX, perlinReturn, rand);
            }
        }
    }

    /**
     * remove trees in given range.
     *
     * @param minX X coordinate to remove tree from.
     * @param maxX X coordinate to remove tree to.
     */
    public void removeInRange(int minX, int maxX) {
        int startX = (int) (blockSize *
                Math.floor((float) minX / blockSize));
        int endX = (int) (blockSize *
                Math.floor((float) maxX / blockSize));
        for (GameObject stump : gameObjects.objectsInLayer(treeLayer)) {
            if (stump.getCenter().x() >= startX &&
                    stump.getCenter().x() <= endX) {
                gameObjects.removeGameObject(stump, treeLayer);
            }
        }
        for (GameObject leaf : gameObjects.objectsInLayer(leafLayer)) {
            if (leaf.getCenter().x() >= startX &&
                    leaf.getCenter().x() <= endX) {
                gameObjects.removeGameObject(leaf, leafLayer);
            }
        }
    }

    /**
     * add leaf movement - transition in angle of leaf and transition in width.
     * @param leaf leaf object.
     */
    private void addLeafMovement(Leaf leaf) {
        Runnable runnable = () -> {
            new Transition<>(leaf, leaf.renderer()::setRenderableAngle,
                    LEAF_INITIAL_ANGLE,
                    LEAF_FINAL_ANGLE, Transition.CUBIC_INTERPOLATOR_FLOAT,
                    LEAF_TRANSITION_ANGLE,
                    Transition.TransitionType.TRANSITION_BACK_AND_FORTH, null);
            new Transition<>(leaf, width -> leaf.setDimensions(new Vector2(width +
                    leaf.getDimensions().y(), leaf.getDimensions().y())),
                    LEAF_INITIAL_DIMENSIONS, LEAF_FINAL_DIMENSIONS,
                    Transition.CUBIC_INTERPOLATOR_FLOAT,
                    LEAF_DIMENSION_TRANSITION_TIME,
                    Transition.TransitionType.TRANSITION_BACK_AND_FORTH, null);
        };
        new ScheduledTask(leaf, rand.nextFloat(), false, runnable);
    }

    /**
     * makes falling leafs by with lifetime and death time.
     * @param leaf leaf Object.
     * @param rand random Object.
     */
    private void addLeafFall(Leaf leaf, Random rand) {
        int lifetime = rand.nextInt(LEAF_LIFTETIME_MAXIMUM + LEAF_LIFETIME_MINIMUM);
        int dieTime = rand.nextInt(LEAF_DIETIME_MAXIMUM) + LEAF_DIETIME_MINIMUM;
        Vector2 originalLocation = leaf.getCenter();
        Runnable onGroundRunnable = () -> {
            leaf.setCenter(originalLocation);
            leaf.renderer().setOpaqueness(FULL_OPAQUNESS);
            leaf.setVelocity(Vector2.ZERO);
            gameObjects.addGameObject(leaf, leafLayer);
            gameObjects.removeGameObject(leaf, fallingLeafLayer);
        };
        Runnable fallRunnable = () -> {
            gameObjects.addGameObject(leaf, fallingLeafLayer);
            gameObjects.removeGameObject(leaf, leafLayer);
            leaf.renderer().fadeOut(FADEOUT_TIME, () ->
                    new ScheduledTask(leaf,
                            dieTime, false, onGroundRunnable));
            leaf.transform().setVelocityY(LEAF_FALLING_SPEED);
            leaf.createHorizontalMovement();
        };
        new ScheduledTask(leaf, lifetime, false, fallRunnable);
    }

    /**
     * adds x coordinate and generated height to tree hash table.
     * @param startX x coordinate of the tree.
     * @return tree height.
     */
    private float treeHahTable(int startX) {
        float treeHeight;
        if (treeXLocationtoHeightMap.containsKey(startX)) {
            treeHeight = treeXLocationtoHeightMap.get(startX);
        } else {
            treeHeight = rand.nextInt(TREE_HEIGHT_MAX) +TREE_HEIGHT_MIN;
            treeXLocationtoHeightMap.put(startX, treeHeight);
        }
        return treeHeight;
    }

    /**
     *  create a stump of a tree and sets his color.
     * @param startX x coordinate of the tree.
     * @param perlinReturn y coordinate of the tree.
     * @param treeHeight height of the tree.
     * @param i y index in col of stumps.
     * @return stump object.
     */
    private Block createStump(int startX, float perlinReturn, float treeHeight, int i) {
        Block stump = new Block(Vector2.ZERO, new RectangleRenderable(TREE_STUMP_COLOR), STUMP_SIZE);
        stump.setCenter(new Vector2(startX, perlinReturn - STUMP_BLOCK_GAP - (i * STUMP_SIZE)));
        if (i == treeHeight) {
            gameObjects.addGameObject(stump, topTreeLayer);
        } else {
            gameObjects.addGameObject(stump, treeLayer);
        }
        return stump;
    }

    /**
     * create a leaf of a tree and sets his color.
     * @param startX x coordinate of the tree.
     * @param perlinReturn y coordinate of the tree.
     * @param treeHeight height of the tree.
     * @param i x index in matrix of leafs.
     * @param j y index in matrix of leafs.
     * @param rand random Object.
     * @return Leaf object.
     */
    private Leaf createLeaf(int startX, float perlinReturn, float treeHeight, int i, int j, Random rand) {
        int random = rand.nextInt(N_POTENTIAL_COLORS);
        Color color;
        if (random < GREEN_THRESHOLD) {
            color = Color.GREEN;
        } else if (random < LIGHT_GREEN_THRESHOLD) {
            color = Color.GREEN.brighter();
        } else if (random < DARK_GREEN_THRESHOLD) {
            color = Color.GREEN.darker();
        } else {
            color = Color.ORANGE;
        }
        Leaf leaf = new Leaf(Vector2.ZERO, new RectangleRenderable(color));
        leaf.setCenter(new Vector2(startX - (i * LEAF_SIZE_PLUS_GAP),
                perlinReturn - (treeHeight * STUMP_SIZE) - (j * LEAF_SIZE_PLUS_GAP)));
        gameObjects.addGameObject(leaf, leafLayer);
        return leaf;
    }

    /**
     * create Tree with blocks of stumps and leafs.
     * @param startX x coordinate to generate tree at.
     * @param perlinReturn y coordinate to generate tree at.
     * @param rand random object.
     */
    private void createTree(int startX, float perlinReturn, Random rand) {
        float treeHeight;
        treeHeight = treeHahTable(startX);
        for (int i = 1; i <= treeHeight; i++) {
            createStump(startX, perlinReturn, treeHeight, i);
        }
        boolean firstTime = true;
        for (int i = -NUMBER_OF_LEAFS; i < NUMBER_OF_LEAFS; i++) {
            for (int j = -NUMBER_OF_LEAFS; j < NUMBER_OF_LEAFS; j++) {
                float leafRand = rand.nextFloat();
                if (leafRand > THRESHOLD_LEAFS) {
                    Leaf leaf = createLeaf(startX, perlinReturn, treeHeight, i, j, rand);
                    if (firstTime) {
                        gameObjects.addGameObject(leaf, fallingLeafLayer);
                        firstTime = false;
                    }
                    addLeafMovement(leaf);
                    addLeafFall(leaf, rand);
                    leaf.setTag(LEAF_TAG);
                }
            }
        }
    }

}