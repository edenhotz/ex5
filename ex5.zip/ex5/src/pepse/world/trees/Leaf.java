package pepse.world.trees;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.components.GameObjectPhysics;
import danogl.components.ScheduledTask;
import danogl.components.Transition;
import danogl.gui.rendering.RectangleRenderable;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

import java.awt.*;
import java.util.function.Consumer;

/**
 * Leaf's class create objects that represent leafs in the game.
 */
public class Leaf extends GameObject {
    private static final int SIZE = 15;
    private static final float INITIAL_LEAF_HORIZIONTAL_LOCATION = (-1) * 5f;
    private static final float FINAL_LEAF_HORIZIONTAL_LOCATION = 5f;
    private static final float LEAF_TRANSITION_TIME = 10;

    private Transition<Float> horizontalMovement;

    /**
     * Construct a new GameObject instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param renderable    The renderable representing the object. Can be null, in which case
     *                      the GameObject will not be rendered.
     */
    public Leaf(Vector2 topLeftCorner, Renderable renderable) {
        super(topLeftCorner, Vector2.ONES.mult(SIZE), renderable);
    }

    /**
     * sets velocity of the leaf to zero when colliding another object.
     * @param other The GameObject with which a collision occurred.
     * @param collision Information regarding this collision.
     *                  A reasonable elastic behavior can be achieved with:
     *                  setVelocity(getVelocity().flipped(collision.getNormal()));
     */
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        renderer().setRenderable(new RectangleRenderable(Color.RED.darker().darker()));
        setVelocity(Vector2.ZERO);
        removeComponent(horizontalMovement);
    }

    /**
     * create horizontal movement of the leaf.
     */
    public void createHorizontalMovement() {
        this.horizontalMovement = new Transition<>(this, speed
                -> this.transform().setVelocityX(speed),
                INITIAL_LEAF_HORIZIONTAL_LOCATION, FINAL_LEAF_HORIZIONTAL_LOCATION,
                Transition.LINEAR_INTERPOLATOR_FLOAT, LEAF_TRANSITION_TIME,
                Transition.TransitionType.TRANSITION_LOOP, null);
    }
}
