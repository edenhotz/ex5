package pepse;

import danogl.GameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.gui.ImageReader;
import danogl.gui.SoundReader;
import danogl.gui.UserInputListener;
import danogl.gui.WindowController;
import danogl.gui.rendering.Camera;
import danogl.util.Vector2;
import pepse.util.EnergyCounter;
import pepse.world.Avatar;
import pepse.world.Sky;
import pepse.world.Terrain;
import pepse.world.daynight.Night;
import pepse.world.daynight.Sun;
import pepse.world.daynight.SunHalo;
import pepse.world.trees.Tree;

import java.awt.Color;
import java.util.Objects;
import java.util.function.Function;

/**
 * PepseGameManager class is running the game.
 */
public class PepseGameManager extends GameManager {
    private static final int SKY_LAYER = -120;
    private static final int SUN_LAYER = -115;
    private static final int HALO_LAYER = -114;
    private static final int GROUND_LAYER = -112;
    private static final int UPPER_TERRAIN_LAYER = -111;
    private static final int TREE_LAYER = -110;
    private static final int TOP_TREE_LAYER = -109;
    private static final int LEAF_LAYER = -108;
    private static final int FALLING_LEAF_LAYER = -107;
    private static final int WINDOW_WIDTH = 700;
    private static final int WINDOW_HEIGHT = 500;
    private static final String WINDOW_TITLE = "Pepse";
    private static final int SEED_CONSTANT = 45;
    private static final float CYCLE_LENGTH = 30;
    private static final int BLOCK_SIZE = 30;
    private static final float CREATING_DELTA = 500;
    private static final float STARTING_WINDOW_FACTOR = 2;
    private static final float HALF_SCREEN_FACTOR = 0.5f;
    private static final int YELLOW = 0x14ffff00;
    private Vector2 windowDimensions;
    private ImageReader imageReader;
    private UserInputListener inputListener;
    private Avatar avatar;
    private Tree tree;
    private Terrain terrain;
    private float curRightHorizontalEdge;
    private float curLeftHorizontalLocation;

    /**
     * PepseGameManager's constructor.
     *
     * @param windowTitle      title to display.
     * @param windowDimensions dimensions of thw window.
     */
    public PepseGameManager(String windowTitle, Vector2 windowDimensions) {
        super(windowTitle, windowDimensions);
    }

    /**
     * initialize all instances of the game.
     *
     * @param imageReader      Contains a single method: readImage, which reads an image from disk.
     *                         See its documentation for help.
     * @param soundReader      Contains a single method: readSound, which reads a wav file from
     *                         disk. See its documentation for help.
     * @param inputListener    Contains a single method: isKeyPressed, which returns whether
     *                         a given key is currently pressed by the user or not. See its
     *                         documentation.
     * @param windowController Contains an array of helpful, self explanatory methods
     *                         concerning the window.
     */
    @Override
    public void initializeGame(ImageReader imageReader, SoundReader soundReader,
                               UserInputListener inputListener, WindowController windowController) {
        super.initializeGame(imageReader, soundReader, inputListener, windowController);
        this.windowDimensions = windowController.getWindowDimensions();
        this.inputListener = inputListener;
        this.imageReader = imageReader;
        curLeftHorizontalLocation = 0;
        curRightHorizontalEdge = windowDimensions.x() * STARTING_WINDOW_FACTOR;
        Sky.create(gameObjects(), windowController.getWindowDimensions(), SKY_LAYER);
        initializeEarth();
        Night.create(gameObjects(), Layer.FOREGROUND, windowController.getWindowDimensions(), CYCLE_LENGTH);
        GameObject sun = Sun.create(gameObjects(), SUN_LAYER, windowController.getWindowDimensions(), CYCLE_LENGTH);
        SunHalo.create(gameObjects(), HALO_LAYER, sun, new Color(YELLOW, true));
        EnergyCounter.createEnergyCounter(avatar, gameObjects(), new Vector2(windowDimensions.mult(0.05f)),
                windowDimensions.mult(0.07f));
    }

    /**
     * initializes Tree and Terrain instances and define layers collisions.
     */
    private void initializeEarth() {
        terrain = new Terrain(gameObjects(), GROUND_LAYER, UPPER_TERRAIN_LAYER,
                windowDimensions, SEED_CONSTANT, BLOCK_SIZE);
        avatarAndMovement(terrain::groundHeightAt);
        terrain.createInRange((int) (curLeftHorizontalLocation - CREATING_DELTA),
                (int) (curRightHorizontalEdge + CREATING_DELTA));
        tree = new Tree(terrain::groundHeightAt, SEED_CONSTANT, BLOCK_SIZE, TREE_LAYER,
                LEAF_LAYER, FALLING_LEAF_LAYER, TOP_TREE_LAYER, gameObjects());
        tree.createInRange((int) (curLeftHorizontalLocation - CREATING_DELTA),
                (int) (curRightHorizontalEdge + CREATING_DELTA));
        gameObjects().layers().shouldLayersCollide(FALLING_LEAF_LAYER,
                UPPER_TERRAIN_LAYER, true);
        gameObjects().layers().shouldLayersCollide(Layer.DEFAULT, UPPER_TERRAIN_LAYER, true);
        gameObjects().layers().shouldLayersCollide(Layer.DEFAULT, GROUND_LAYER, true);
        gameObjects().layers().shouldLayersCollide(Layer.DEFAULT, TOP_TREE_LAYER, true);
    }

    /**
     * creates avatar instance and sets the camera to follow avatar.
     *
     * @param groundHeightAt function that calculates ground height at X axis.
     */
    private void avatarAndMovement(Function<Float, Float> groundHeightAt) {
        float initialX = windowDimensions.multX(HALF_SCREEN_FACTOR).x();
        avatar = Avatar.create(gameObjects(), Layer.DEFAULT,
                new Vector2(initialX, groundHeightAt.apply(initialX)), inputListener, imageReader);
        setCamera(new Camera(avatar, windowDimensions.mult(HALF_SCREEN_FACTOR).subtract(avatar.getCenter()),
                windowDimensions, windowDimensions));
    }

    /**
     * creates and removes instances in defined range according to camera coordinates.
     *
     * @param deltaTime The time, in seconds, that passed since the last invocation
     *                  of this method (i.e., since the last frame). This is useful
     *                  for either accumulating the total time that passed since some
     *                  event, or for physics integration (i.e., multiply this by
     *                  the acceleration to get an estimate of the added velocity or
     *                  by the velocity to get an estimate of the difference in position).
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        if (camera().getCenter().x() > curRightHorizontalEdge - CREATING_DELTA) {
            createObjects(curRightHorizontalEdge, curRightHorizontalEdge + CREATING_DELTA);
            removeObjects(curLeftHorizontalLocation, curLeftHorizontalLocation + CREATING_DELTA);
            curRightHorizontalEdge += CREATING_DELTA;
            curLeftHorizontalLocation += CREATING_DELTA;

        } else if (camera().getCenter().x() < curLeftHorizontalLocation + CREATING_DELTA) {
            createObjects(curLeftHorizontalLocation - CREATING_DELTA, curLeftHorizontalLocation);
            removeObjects(curRightHorizontalEdge - CREATING_DELTA, curRightHorizontalEdge);
            curRightHorizontalEdge -= CREATING_DELTA;
            curLeftHorizontalLocation -= CREATING_DELTA;
        }
    }

    /**
     * create tress and blocks of terrain  in given range.
     *
     * @param curLeftHorizontalLocation left coordinate to create object from.
     * @param curRightHorizontalEdge    right coordinate to create object to.
     */
    private void createObjects(float curLeftHorizontalLocation, float curRightHorizontalEdge) {
        terrain.createInRange((int) curLeftHorizontalLocation, (int) curRightHorizontalEdge);
        tree.createInRange((int) curLeftHorizontalLocation, (int) curRightHorizontalEdge);
    }

    /**
     * remove tress and blocks of terrain  in given range.
     *
     * @param curLeftHorizontalLocation left coordinate to remove object from.
     * @param curRightHorizontalEdge    right coordinate to remove object to.
     */
    private void removeObjects(float curLeftHorizontalLocation, float curRightHorizontalEdge) {
        terrain.removeInRange((int) curLeftHorizontalLocation, (int) curRightHorizontalEdge);
        tree.removeInRange((int) curLeftHorizontalLocation, (int) curRightHorizontalEdge);
    }

    public static void main(String[] args) {
        new PepseGameManager(WINDOW_TITLE, new Vector2(WINDOW_WIDTH, WINDOW_HEIGHT)).run();
    }

}